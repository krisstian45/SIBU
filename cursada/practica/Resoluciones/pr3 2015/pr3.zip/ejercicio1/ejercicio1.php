<!DOCTYPE html>
<html>
<head>
		<title>Contador de visitas</title>
		<meta http­-equiv="content­type" content="text/html;charset=utf­-8" />
</head>
	<body>
		<h1> Contador de la pr&aacutectica 1</h1>
		<h2> Tener en cuenta los permisos del archivo.... </h2>
	<?php
	$arch="count.txt";
	if (file_exists($arch)){
		$fcont=fopen($arch, "r+");
		$linea=fread($fcont, filesize($arch));
		fclose($fcont);
	}
	else $linea=0;

	$fcont=fopen($arch,"w");
	$cont=(int)$linea +1;
	$linea=fwrite($fcont,$cont);
	echo "<h3>Contador de accesos:  $cont</h3>";
	fclose($fcont);
	?>
	</body>
</html>