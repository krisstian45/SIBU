<?php 

	header("Location: entrega1/frontend.html");

/*$host = gethostname();

if (!$host == "cristian-K" || !$host == "feliaranaLenovo")
	header("Location: entrega1/frontend.html");
*/

?>